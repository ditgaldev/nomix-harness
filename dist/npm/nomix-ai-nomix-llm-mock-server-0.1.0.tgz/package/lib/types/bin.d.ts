#!/usr/bin/env node
/**
 * Standalone process wrapper for the scriptable mock LLM server.
 * @module @nomix-ai/nomix-llm-mock-server/src/bin
 */
export {};
//# sourceMappingURL=bin.d.ts.map