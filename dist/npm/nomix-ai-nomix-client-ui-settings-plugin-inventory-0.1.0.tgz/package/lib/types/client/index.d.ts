/** Read-only Host plugin inventory registered into Web Settings. */
import type { ClientContext } from '@nomix-ai/nomix-client-runtime/client';
import { type PluginInventoryLocaleKey } from './locales.ts';
export type { PluginInventorySettingsTabInjected, PluginInventorySettingsTabProps } from './PluginInventorySettingsTab.tsx';
export type { PluginInventoryLocaleKey } from './locales.ts';
declare module '@nomix-ai/nomix-client-ui-slots' {
    interface LocaleNamespaceMap {
        /** Read-only Host plugin inventory copy. */
        'settings.pluginInventory': PluginInventoryLocaleKey;
    }
}
/** Dictionary namespace owned by this plugin. */
export declare const NS = "settings.pluginInventory";
/** Services required by the Settings registration and generated Remote face. */
export declare const inject: string[];
/** Contribute the lazy inventory tab to the Plugins settings section. */
export declare function apply(ctx: ClientContext): void;
//# sourceMappingURL=index.d.ts.map