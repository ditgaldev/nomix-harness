/**
 * JSON storage backend: one human-readable file per unit under a configured
 * root, published by atomic whole-file rewrite. Registers as backend `json`
 * on the storage hub.
 * @module @nomix-ai/nomix-storage-json
 */
import type { Context } from '@nomix-ai/cordis';
import z from '@nomix-ai/schemastery';
import type { KvFacet, StorageBackend } from '@nomix-ai/nomix-storage';
/** Cordis plugin name. */
export declare const name = "storage-json";
/** The hub must exist before the backend can register. */
export declare const inject: string[];
/**
 * Plugin configuration.
 * `root` has NO default on purpose: a `process.cwd()` fallback would scatter
 * unit files wherever the process happens to start; assemblies state the
 * location explicitly.
 */
export interface Config {
    /** Directory holding one `<unit>.json` file per unit. */
    root: string;
}
/** Config schema. */
export declare const Config: z<Config>;
/** JSON backend: owns the file-tree root and serves the `kv` facet. */
export declare class JsonStorageBackend implements StorageBackend {
    private readonly root;
    private readonly open;
    private readonly opening;
    private closed;
    constructor(root: string);
    readonly kv: KvFacet;
    private openUnit;
    close(): Promise<void>;
}
/**
 * Register the `json` backend on the storage hub.
 * @param ctx - Plugin context.
 * @param config - Validated configuration.
 */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map