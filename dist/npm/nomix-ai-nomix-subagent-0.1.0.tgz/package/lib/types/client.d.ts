/**
 * Browser-safe subagent projection vocabulary.
 *
 * @module @nomix-ai/nomix-subagent/client
 */
export type { SubagentIdentityProjection, SubagentTimingProjection } from './projection-types.ts';
//# sourceMappingURL=client.d.ts.map