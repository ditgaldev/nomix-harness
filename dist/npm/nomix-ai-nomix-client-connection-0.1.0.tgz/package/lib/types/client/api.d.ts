export type { ApiProxy, SessionsApi, SessionSearchItem, SessionSummary, PromptContentPart, HostApi, EventsApi, MuxFrame, HostFrame, ApprovalResponsePayload, QuestionResponsePayload, HistoryEntry, ToolEventView, DirectoryEntry, DirectoryListing, ResponseValue, WorkspaceApi, WorkspaceId, WorkspaceView, SkillsApi, SkillEntry, ModelCatalogFailure, ModelCatalogModel, ModelProviderGroup, ModelReasoning, ModelReasoningEffort, ModelSelection, QueueAction, QueuedInboxItem, SessionModels, GoalsApi, GoalRef, SettingsApi, SettingsNamespaceView, SettingsPathOpView, SettingsSecretView, CredentialsApi, CredentialView, ConfigurableProviderView, DiscoveredModelView, LlmApi, SubagentsApi, SubagentAddress, SubagentCatalog, SubagentListEntry, SubagentPromptReceipt, JobView, } from '@nomix-ai/nomix-host-apiproxy/api';
export type { ToolCallView, ToolResultView } from '@nomix-ai/nomix-tools/presentation';
export type { RpcRequest, RpcResponse, RpcResult, RpcError, RpcErrorCode, ClientRequest, ServerResponse, ServerRequest, ClientResponse, RpcMessage, RpcReceipt, } from '@nomix-ai/nomix-host-apiproxy/api';
export { RpcId, SESSION_SEARCH_RESULT_LIMIT, transportError, } from '@nomix-ai/nomix-host-apiproxy/api';
export { AbstractApiClient } from '@nomix-ai/nomix-host-apiproxy/client';
export type { IApiClient } from '@nomix-ai/nomix-host-apiproxy/client';
export type { SessionId, SessionEvent } from '@nomix-ai/nomix-session/types';
export type { MessageId } from '@nomix-ai/nomix-llm/brand';
export type { ContentBlock, StreamChunk } from '@nomix-ai/nomix-llm/types';
/** Successful value returned by the connection-generation host handshake. */
export type HostDescription = import('@nomix-ai/nomix-host-apiproxy/api').ResponseValue<'host.describe'>;
import type { RpcResponse, RpcResult } from '@nomix-ai/nomix-host-apiproxy/api';
/**
 * Unwrap a unary response: RpcResponse<T> -> RpcResult<T> (business code only
 * cares about the result slot).
 * @param response - the unary response.
 * @returns its result slot.
 */
export declare function resultOf<T>(response: RpcResponse<T>): RpcResult<T>;
//# sourceMappingURL=api.d.ts.map