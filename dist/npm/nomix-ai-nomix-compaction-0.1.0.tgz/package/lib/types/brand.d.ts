import type { Branded } from '@nomix-ai/nomix-brand';
/** Stable identity shared by one compact start/summary/checkpoint/end transaction. */
export type CompactionId = Branded<'CompactionId'>;
/**
 * Brand an implementation-minted compaction identity.
 * @param id - opaque transaction identity.
 * @returns the same string, branded; no validation is performed.
 */
export declare function CompactionId(id: string): CompactionId;
//# sourceMappingURL=brand.d.ts.map