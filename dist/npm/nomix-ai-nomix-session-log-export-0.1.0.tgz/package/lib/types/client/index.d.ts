/** Browser plugin owning Session export download state and its shared modal. */
import type { ClientContext } from '@nomix-ai/nomix-client-runtime/client';
import { SessionLogDownloadController } from './controller.ts';
import { type SessionLogDownloadKey } from './locales.ts';
declare module '@nomix-ai/cordis' {
    interface Context {
        sessionLogDownload: SessionLogDownloadController;
    }
}
declare module '@nomix-ai/nomix-client-ui-slots' {
    interface LocaleNamespaceMap {
        'session-log-download': SessionLogDownloadKey;
    }
}
export type { SessionLogDownloadEntry, SessionLogDownloadState } from './controller.ts';
export declare const inject: string[];
/**
 * Provide the download controller and mount its modal into the Session Header.
 * @param ctx - browser context carrying slots and locale services.
 */
export declare function apply(ctx: ClientContext): void;
export type { SessionLogDownloadDialogInjected, SessionLogDownloadDialogProps } from './Dialog.tsx';
//# sourceMappingURL=index.d.ts.map