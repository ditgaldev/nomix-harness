import type { Context } from '@nomix-ai/cordis';
/**
 * Register the Trajectory Assistant lifecycle.
 *
 * @param ctx - Plugin context receiving the Definitions.
 */
export declare function registerTrajectoryAssistantDefinition(ctx: Context): void;
//# sourceMappingURL=trajectory-assistant-definition.d.ts.map