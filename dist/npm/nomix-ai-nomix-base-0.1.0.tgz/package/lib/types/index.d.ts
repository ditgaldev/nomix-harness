/**
 * @nomix-ai/nomix-base — the shared dsh core as a profile bundle. The
 * package's substance is `cordis.patch.yml`, declared by the `dsh.bundle.patch`
 * manifest field and resolved by the profile composer through that field;
 * this module carries no runtime API.
 * @module @nomix-ai/nomix-base
 */
export {};
//# sourceMappingURL=index.d.ts.map