/** Package-owned durable clock-context invariants. @module @nomix-ai/nomix-time-context/invariant */
import type { Context } from '@nomix-ai/cordis';
/** Cordis companion plugin name. */
export declare const name = "time-context-invariant";
/** Service required before the companion can reserve package ownership. */
export declare const inject: string[];
/**
 * Register the time-context invariant companion.
 * @param ctx - Cordis context carrying the invariant service.
 * @returns the installed registration's disposer after setup succeeds.
 */
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map