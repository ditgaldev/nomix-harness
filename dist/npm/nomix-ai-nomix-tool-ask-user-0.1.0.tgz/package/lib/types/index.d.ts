/**
 * Model-facing Consumer of the `ctx.userQuestions` capability seam.
 * The tool pauses until a UI provider returns a human answer, then feeds that
 * answer back into the agent loop as an ordinary tool result.
 *
 * @module @nomix-ai/nomix-tool-ask-user
 */
import type { Context } from '@nomix-ai/cordis';
import '@nomix-ai/nomix-user-questions';
export declare const name = "tool-ask-user";
export declare const inject: string[];
export declare function apply(ctx: Context): void;
//# sourceMappingURL=index.d.ts.map