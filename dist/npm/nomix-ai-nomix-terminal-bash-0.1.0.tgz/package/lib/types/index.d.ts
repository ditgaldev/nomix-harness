/**
 * Persistent shell PTY backend over the subprocess terminal primitive, shared
 * sandbox policy, bounded output, and provider-owned session cleanup.
 * @module @nomix-ai/nomix-terminal-bash
 */
import { Context } from '@nomix-ai/cordis';
import type { TerminalBackend, TerminalBackendSpawnSpec } from '@nomix-ai/nomix-terminal';
import type { SubprocessTerminalHandle, SubprocessTerminalSpawnSpec } from '@nomix-ai/nomix-subprocess';
import { type Config, type ResolvedConfig } from './config.ts';
import { LocalPtySession } from './session.ts';
export { Config } from './config.ts';
export type { Config as TerminalLocalConfig } from './config.ts';
/** Cordis plugin name. */
export declare const name = "terminal-bash";
/** Required services: PTY registry, shared confinement policy, and process substrate. */
export declare const inject: string[];
/** Local shell backend registered under the configured type. */
export declare class BashTerminalBackend implements TerminalBackend {
    private readonly ctx;
    private readonly config;
    private readonly spawnTerminal;
    private readonly createSession;
    readonly type: string;
    constructor(ctx: Context, config: ResolvedConfig, spawnTerminal?: (spec: SubprocessTerminalSpawnSpec) => Promise<SubprocessTerminalHandle>, createSession?: (terminal: SubprocessTerminalHandle, config: ResolvedConfig) => LocalPtySession);
    spawn(spec: TerminalBackendSpawnSpec): Promise<LocalPtySession>;
}
/** Register the local PTY backend. */
export declare function apply(ctx: Context, config: Config): void;
//# sourceMappingURL=index.d.ts.map