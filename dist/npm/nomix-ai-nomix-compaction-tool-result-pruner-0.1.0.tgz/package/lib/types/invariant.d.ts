/**
 * Package-owned invariant companion for `@nomix-ai/nomix-compaction-tool-result-pruner`.
 * @module @nomix-ai/nomix-compaction-tool-result-pruner/invariant
 */
import type { Context } from '@nomix-ai/cordis';
/** Cordis companion plugin name. */
export declare const name = "compaction-tool-result-pruner-invariant";
/** Services required before the companion can register. */
export declare const inject: string[];
/**
 * Register this package's invariant companion.
 * @param ctx - Cordis context carrying the invariant service.
 * @returns the installed registration's disposer after setup succeeds.
 */
export declare const apply: (ctx: Context) => Promise<() => void>;
//# sourceMappingURL=invariant.d.ts.map