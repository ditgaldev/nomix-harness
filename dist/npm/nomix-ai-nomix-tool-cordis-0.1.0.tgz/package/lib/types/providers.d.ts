/** First-party Host inspect providers registered by the Cordis tool package. */
import type { Context } from '@nomix-ai/cordis';
import type { HostCordisInspectProviderRegistration } from '@nomix-ai/nomix-cordis-host-runner';
/**
 * Construct Host providers over generated Catalogs, evaluator declarations, and live Tool scope.
 * @param ctx - Host context used for Agent-scoped live Tool queries.
 * @returns registrations for static catalogs and live Host capabilities.
 */
export declare function hostInspectProviders(ctx: Context): HostCordisInspectProviderRegistration[];
//# sourceMappingURL=providers.d.ts.map